
let xPlayer = 70;
let yPlayer = 368;
let myScore = 0;

function showPlayer() {
    image(imgPlayer, 20, yPlayer, 30, 30);
}

function incluirPontos() {
    text(myScore, 20,25)
    fill(color(255,0,0))
    textSize (21)
    
}
function movimentoPlayer() {

    if(keyIsDown(UP_ARROW)){

        yPlayer -=3; 
    }
    
    if(keyIsDown(DOWN_ARROW)){

        yPlayer +=3; 
    }
}

function checkCollision(rectA, rectB) {
    return (
      xPlayer.x < xCarros.x + xCarros.width &&
      xPlayer.x + xCarros.width > xCarros.x &&
      yPlayer.y < yCarros.y + yCarros.height &&
      yPlayer.y + yCarros.height > yCarros.y
    );
}
