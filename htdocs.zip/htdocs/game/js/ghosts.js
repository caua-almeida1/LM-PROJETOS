let xCarros = [700, 700, 700, 700, 700, 700];
let yCarros = [100, 50, 158, 220, 270, 325];
let velocidadeGhosts = [6, 2, 6, 9, 5, 2];

let comprimentoGhost = 40;
let alturaGhost = 30;


function mostrarGhosts() {
  for (let i = 0; i < xCarros.length; i++) {
    image(imgGhosts[i], xCarros[i], yCarros[i], comprimentoGhost, alturaGhost);
  }
}

function movimentoCarro() {
  for (let i = 0; i < xCarros.length; i++) {
    xCarros[i] -= velocidadeGhosts[i];
    
    // Se o carro saiu da tela, reposicione-o no lado direito
    if (xCarros[i] < -comprimentoGhost) {
      xCarros[i] = width; // width é a largura da tela
    }
  }
}

checkGhost
