const scriptFrames = document.getElementById("script");

let imgStreet;
let imgPlayer;
let imgGhost1;
let imgGhost2;
let imgGhost3;

let imgGhosts;

function preload(){

    imgStreet = loadImage("img/estrada.png");
    imgPlayer = loadImage("img/mascote - Copia.png");
    imgGhost1 = loadImage("img/carro-1.png");
    imgGhost2 = loadImage("img/carro-2.png");
    imgGhost3 = loadImage("img/carro-3.png");

    imgGhosts = [imgGhost1, imgGhost2, imgGhost3,
    imgGhost1, imgGhost2, imgGhost3];
}