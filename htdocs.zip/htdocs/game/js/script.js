
//função setup defini configuração de largura e altura

function setup() {

    createCanvas(700, 400);
    
}

//função de desenho definindo o que será exibido
function draw() {

    background(imgStreet);
    //image onde manipulamos o objeto em eixo X e Y, ou também a largura e altura
    showPlayer();
    mostrarGhosts();
    movimentoCarro();
    movimentoPlayer();
    incluirPontos();
}

