function mode() {
    const html = document.documentElement;
    html.classList.toggle("claro");

    const iconElement = document.querySelector("[icon='mi:sun']");

    const img = document.querySelector(".profile img");

    if (html.classList.contains("claro")) {
        document.body.style.backgroundColor = "rgb(255, 57, 57)";

        iconElement.setAttribute("icon", "mi:moon");
    } else {
        document.body.style.backgroundColor = "#1e1f32";
        iconElement.setAttribute("icon", "mi:sun");
    }
}
