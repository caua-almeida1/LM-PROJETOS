let xCarros = [700, 700, 700, 700, 700, 700];
let yCarros = [48, 105, 159, 213, 269, 330];
let velocidadeGhosts = [4, 3, 8, 9, 6, 10];

let comprimentoGhost = 30;
let alturaGhost = 30;


function mostrarGhosts() {
  for (let i = 0; i < xCarros.length; i++) {

  image(imgGhosts[i], xCarros[i], yCarros[i], 40, 30);
  }
}

function movimentoCarro() {
  for (let i = 0; i < imgGhosts.length; i++) {
    xCarros[i] -= velocidadeGhosts[i];
    
    // Se o carro saiu da tela, reposicione-o no lado direito
      if (xCarros[i] < -comprimentoGhost) {
          xCarros[i] = width; // width é a largura da tela
      }
  }
}