
let xPlayer = 30;
let yPlayer = 368;
let myScore = 0;
let cont = 1;

let colision = false

function verifyColision() {
    for (let i = 0; i < imgGhosts.length; i++) {
      colision = collideRectCircle(xCarros[i], yCarros[i], comprimentoGhost, alturaGhost, xPlayer, yPlayer, 5);
      
      if (colision) {
        returnScore();
        if (myScore > 0) {
            myScore -=1;
        }
      }
    }
  
    print('Colisão acontecendo', colision);
  }


function returnScore() {
    yPlayer = 400;
}

function incluirPontos() {
    text(myScore, 20,25)
    fill(color(255,0,0))
    textSize (21)
    
    if (yPlayer <0) {
        yPlayer = 360
        myScore ++
    }
}
function movimentoPlayer() {

    if(keyIsDown(UP_ARROW)){

        yPlayer -=3; 
    }
    
    if(keyIsDown(DOWN_ARROW)){

        yPlayer +=3; 
    }

    if(keyIsDown(LEFT_ARROW)){

        xPlayer -=3; 
    }

    if(keyIsDown(RIGHT_ARROW)){

        xPlayer +=3; 
    }
}