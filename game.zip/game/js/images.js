const scriptFrames = document.getElementById("script");

let imgStreet;
let imgPlayer;
let imgGhost1;
let imgGhost2;
let imgGhost3;

let imgGhosts;

function preload() {
    imgStreet = loadImage("img/estrada.png");
    imgPlayer = loadImage(`img/sprite/Walk_1.png`); // Carregue a primeira imagem do sprite
    imgGhost1 = loadImage("img/carro-1.png");
    imgGhost2 = loadImage("img/carro-2.png");
    imgGhost3 = loadImage("img/carro-3.png");

    imgGhosts = [imgGhost1, imgGhost2, imgGhost3,
    imgGhost1, imgGhost2, imgGhost3];
}

function setup() {
    createCanvas(700, 400);
    // Carregar o fundo aqui, no começo da função setup
    background(imgStreet);
}


function verifyColision() {
    // ...
}

function returnScore() {
    // ...
}

function showPlayer() {
    image(imgPlayer, xPlayer, yPlayer, 30, 30);
}

function incluirPontos() {
    // ...
}

function movimentoPlayer() {
    // ...
}
